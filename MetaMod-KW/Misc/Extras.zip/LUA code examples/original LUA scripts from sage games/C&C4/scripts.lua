--- define lua functions 
function NoOp(self, source)
end


function kill(self) -- Kill unit self.
	ExecuteAction("NAMED_KILL", self);
end

function RadiateUncontrollableFear( self )
	ObjectBroadcastEventToEnemies( self, "BeUncontrollablyAfraid", 350 )
end

function RadiateGateDamageFear(self)
	ObjectBroadcastEventToAllies(self, "BeAfraidOfGateDamaged", 200)
end

function OnNeutralGarrisonableBuildingCreated(self)
	ObjectHideSubObjectPermanently( self, "ARMOR", true )
end

function OnGDITechCenterCreated(self)
	ObjectHideSubObjectPermanently( self, "UG_Boost", true )
	ObjectHideSubObjectPermanently( self, "UG_Mortar", true )
	ObjectHideSubObjectPermanently( self, "B_MortarRound_1", true )
	ObjectHideSubObjectPermanently( self, "UG_Rail", true )
	ObjectHideSubObjectPermanently( self, "UG_Scan", true )
end

function OnGDIMedicalBayCreated(self)
	ObjectHideSubObjectPermanently( self, "UG_Armor", true )
	ObjectHideSubObjectPermanently( self, "UG_StealthDetector", true )
	ObjectHideSubObjectPermanently( self, "UG_StealthDetector01", true )
	ObjectHideSubObjectPermanently( self, "UG_Injector", true )
end

function OnGDIPowerPlantCreated(self)
	ObjectHideSubObjectPermanently( self, "Turbines", true )
	ObjectHideSubObjectPermanently( self, "TurbineGlows", true )
end

function OnGDIInfantryCCreated(self)
	ObjectHideSubObjectPermanently( self, "UGSCANNER", true )
	ObjectHideSubObjectPermanently( self, "UGJUMP", true )
	ObjectHideSubObjectPermanently( self, "UGINJECTOR", true )
end

function OnGDIVehicleAGCreated(self)
	ObjectHideSubObjectPermanently( self, "GUL_VehicleAG_UPG", true )
	ObjectHideSubObjectPermanently( self, "UPG_SHIELD_FX", true )
end

function OnGDIVehicleAGHuskCreated(self)
	OnGDIVehicleAGCreated( self )
	ObjectClearObjectStatus( self, "CANNOT_PROVIDE_BUILDABILITY" )
	OnBaseHuskCreatorCreated(self)
end

function OnGDIVehicleDCreated(self)
	ObjectHideSubObjectPermanently( self, "GUL_VehicleD_UPG", true )
	ObjectHideSubObjectPermanently( self, "UGRAIL_01", true )
	ObjectHideSubObjectPermanently( self, "UGRAIL_02", true )
	ObjectHideSubObjectPermanently( self, "MuzzleFlash_01", true )
	ObjectHideSubObjectPermanently( self, "MuzzleFlash_02", true )
	OnBaseHuskCreatorCreated(self)
end

function OnGDIVehicleDHuskCreated(self)
	OnGDIVehicleDCreated( self )
	ObjectClearObjectStatus( self, "CANNOT_PROVIDE_BUILDABILITY" )
end


function OnGDIVehicleGCreated(self)
	ObjectHideSubObjectPermanently( self, "MuzzleFlash_01", true )
	ObjectHideSubObjectPermanently( self, "MuzzleFlash_02", true )
	ObjectHideSubObjectPermanently( self, "MuzzleFlash_03", true )
	ObjectHideSubObjectPermanently( self, "Upgrade", true )	
end

function OnGDIVehicleHCreated(self)
	ObjectHideSubObjectPermanently( self, "GUVehicleH_UPG", true )
end

function OnGDIWatchTowerCreated(self)
	ObjectHideSubObjectPermanently( self, "MuzzleFlash_01", true )
	ObjectHideSubObjectPermanently( self, "MuzzleFlash_02", true )
end

function OnGDIAircraftBCreated(self)
	-- bomb load by default.
	ObjectGrantUpgrade( self, "Upgrade_SelectLoad_02" )
	ObjectGrantUpgrade( self, "Upgrade_SelectLoad_02_Desired" )
	ObjectHideSubObjectPermanently( self, "Plane04", true )
end

function OnGDIVehicleJCreated(self)
	ObjectHideSubObjectPermanently( self, "MortorTube", true )
end

function OnGDIAircraftACreated(self)
	ObjectHideSubObjectPermanently( self, "UG_PROBE", true )
end

function OnGDIInfantryFSquadCreated(self)
	ObjectSetObjectStatus( self, "CAN_SPOT_FOR_BOMBARD" )
end

function OnGDIOrcaClipEmpty(self)
	ObjectHideSubObjectPermanently( self, "MISSILE01", true )
end

function OnGDIOrcaClipFull(self)
	ObjectHideSubObjectPermanently( self, "MISSILE01", false )
end

function OnNODShredderCreated(self)

end

function OnNODVehicleDCreated(self)
	ObjectHideSubObjectPermanently( self, "Gun_Upgrade", true )
	ObjectHideSubObjectPermanently( self, "Turret2_Gun", true )
	ObjectHideSubObjectPermanently( self, "Turret2", true )
	ObjectHideSubObjectPermanently( self, "MuzzleFlash_01", true )
	ObjectHideSubObjectPermanently( self, "DOZERBLADE", true )
end

function OnNODVehicleGCreated(self)
	ObjectHideSubObjectPermanently( self, "NUBEAM", true )
	ObjectHideSubObjectPermanently( self, "FLAMETANK", true )
	ObjectHideSubObjectPermanently( self, "S_DETECTOR", true )
	ObjectHideSubObjectPermanently( self, "S_GENERATOR", true )
	OnBaseHuskCreatorCreated(self)
end

function OnNODVehicleGGenericEvent(self, data)

	local str = tostring( data )

	if str == "upgrades_copied" then
		ObjectRemoveUpgrade( self, "Upgrade_Veterancy_VETERAN" );
		ObjectRemoveUpgrade( self, "Upgrade_Veterancy_ELITE" );
		ObjectRemoveUpgrade( self, "Upgrade_Veterancy_HEROIC" );
	end
end

function OnNODVehicleACreated(self)
	ObjectHideSubObjectPermanently( self, "NUS_VehicleA_UPG", true )
end

function OnNODVehicleADCreated(self)
	ObjectHideSubObjectPermanently( self, "NUL_VehicleAD_upgrade", true )

	ObjectHideSubObjectPermanently( self, "ModuleTag_Spider01", true )
	ObjectHideSubObjectPermanently( self, "ModuleTag_Spider02", true )
	ObjectHideSubObjectPermanently( self, "ModuleTag_Spider03", true )
	ObjectHideSubObjectPermanently( self, "ModuleTag_Spider04", true )
	ObjectHideSubObjectPermanently( self, "ModuleTag_Spider05", true )
	ObjectHideSubObjectPermanently( self, "ModuleTag_Spider06", true )
end

function OnNODVehicleADHuskCreated(self)
	OnNODVehicleADCreated( self )
	ObjectClearObjectStatus( self, "CANNOT_PROVIDE_BUILDABILITY" )
end

function NODVehicleAFHuskFunctions(self)
	ObjectClearObjectStatus( self, "CANNOT_PROVIDE_BUILDABILITY" )
end

function OnNODVehicleADContainCountChanged(self, countData)

	local count = tonumber( countData )
	
	local hidetag1 = count < 1
	local hidetag2 = count < 2
	local hidetag3 = count < 3
	local hidetag4 = count < 4
	local hidetag5 = count < 5
	local hidetag6 = count < 6

	ObjectHideSubObjectPermanently( self, "ModuleTag_Spider01", hidetag1 )
	ObjectHideSubObjectPermanently( self, "ModuleTag_Spider02", hidetag2 )
	ObjectHideSubObjectPermanently( self, "ModuleTag_Spider03", hidetag3 )
	ObjectHideSubObjectPermanently( self, "ModuleTag_Spider04", hidetag4 )
	ObjectHideSubObjectPermanently( self, "ModuleTag_Spider05", hidetag5 )
	ObjectHideSubObjectPermanently( self, "ModuleTag_Spider06", hidetag6 )

end

function OnNODAircraftACreated(self)
	ObjectHideSubObjectPermanently( self, "SigGen", true )
end

function OnNODAircraftNCreated(self)
	ObjectHideSubObjectPermanently( self, "UPgrade", true )
end

function OnNODVehicleLCreated(self)
	ObjectHideSubObjectPermanently( self, "NUM_VehicleL_UPG", true )
	ObjectHideSubObjectPermanently( self, "NUM_VehicleL_UPG1", true )
	--ObjectHideSubObjectPermanently( self, "TREDS", true )
end

function OnNODTechAssembleyPlantCreated(self)
	ObjectHideSubObjectPermanently( self, "UG_EMP", true )
	ObjectHideSubObjectPermanently( self, "UG_Lasers", true )
	ObjectHideSubObjectPermanently( self, "UG_SigGen", true )
	ObjectHideSubObjectPermanently( self, "UG_DozerBlades", true )
end

function OnNODSecretShrineCreated(self)
	ObjectHideSubObjectPermanently( self, "GLOWS", true )	
	ObjectHideSubObjectPermanently( self, "ConfUpgrd", true )
end

function OnNODSecretShrinePowerOutage(self)	
	if ObjectHasUpgrade( self, "Upgrade_NODConfessorUpgrade" ) == 1 then
		ObjectHideSubObjectPermanently( self, "GLOWS", true )	
	end
end

function OnNODSecretShrinePowerRestored(self)		 
	if ObjectHasUpgrade( self, "Upgrade_NODConfessorUpgrade" ) == 1 then
		ObjectHideSubObjectPermanently( self, "GLOWS", false )	
	end
end

function onCreatedControlPointFunctions(self)
	ObjectHideSubObjectPermanently( self, "TB_CP_ALN", true )
	ObjectHideSubObjectPermanently( self, "TB_CP_GDI", true )
	ObjectHideSubObjectPermanently( self, "TB_CP_NOD", true )
	ObjectHideSubObjectPermanently( self, "LIGHTSF01", true )
	ObjectHideSubObjectPermanently( self, "100", false)
	ObjectHideSubObjectPermanently( self, "75", false)
	ObjectHideSubObjectPermanently( self, "50", false)
	ObjectHideSubObjectPermanently( self, "25", false )
end

function onBuildingPowerOutage(self)
	ObjectHideSubObjectPermanently( self, "LIGHTS", true )
	ObjectHideSubObjectPermanently( self, "FXLIGHTS05", true )
	ObjectHideSubObjectPermanently( self, "FXLIGHTS", true )
	ObjectHideSubObjectPermanently( self, "FXGLOWS", true )
	ObjectHideSubObjectPermanently( self, "FLASHINGLIGHTS", true )
	ObjectHideSubObjectPermanently( self, "MESH01", true )
	ObjectHideSubObjectPermanently( self, "POWERPLANTGLOWS", true )
	ObjectHideSubObjectPermanently( self, "LIGHTL", true )
	ObjectHideSubObjectPermanently( self, "LIGHTR", true )
	ObjectHideSubObjectPermanently( self, "LIGHTS1", true )
	ObjectHideSubObjectPermanently( self, "NBCHEMICALPTE1", true )
	ObjectHideSubObjectPermanently( self, "LINKS", true )
	ObjectHideSubObjectPermanently( self, "MESH28", true )
	ObjectHideSubObjectPermanently( self, "TURBINEGLOWS", true )
	ObjectHideSubObjectPermanently( self, "GLOWS", true )
end

function onBuildingPowerRestored(self)
	ObjectHideSubObjectPermanently( self, "LIGHTS", false )
	ObjectHideSubObjectPermanently( self, "FXLIGHTS05", false )
	ObjectHideSubObjectPermanently( self, "FXLIGHTS", false )
	ObjectHideSubObjectPermanently( self, "FXGLOWS", false )
	ObjectHideSubObjectPermanently( self, "FLASHINGLIGHTS", false )
	ObjectHideSubObjectPermanently( self, "MESH01", false )
	ObjectHideSubObjectPermanently( self, "POWERPLANTGLOWS", false )
	ObjectHideSubObjectPermanently( self, "LIGHTL", false )
	ObjectHideSubObjectPermanently( self, "LIGHTR", false )
	ObjectHideSubObjectPermanently( self, "LIGHTS1", false )
	ObjectHideSubObjectPermanently( self, "NBCHEMICALPTE1", false )
	ObjectHideSubObjectPermanently( self, "LINKS", false )
	ObjectHideSubObjectPermanently( self, "MESH28", false )
	ObjectHideSubObjectPermanently( self, "TURBINEGLOWS", false )
	ObjectHideSubObjectPermanently( self, "GLOWS", false )
end







function OnNeutralGarrisonableBuildingGenericEvent(self,data)
end

function onCreatedGDIOrcaAirstrike(self)
	ObjectForbidPlayerCommands( self, true )
end

function onCreatedAlienMCVUnpacking(self)
	ObjectForbidPlayerCommands( self, true )
end

function MakeMeAlert(self)
	ObjectEnterAlertState(self)
end

function BecomeUncontrollablyAfraid(self, other)
	if not ObjectTestCanSufferFear(self) then
		return
	end

	ObjectEnterUncontrollableCowerState(self, other)
end

function RadiateTerror(self, other)
	ObjectBroadcastEventToEnemies(self, "BeTerrified", 180)
end
	
function RadiateTerrorEx(self, other, terrorRange)
	ObjectBroadcastEventToEnemies(self, "BeTerrified", terrorRange)
end
	

function BecomeTerrified(self, other)
	ObjectEnterRunAwayPanicState(self, other)
end

function BecomeAfraidOfGateDamaged(self, other)
	if not ObjectTestCanSufferFear(self) then
		return
	end

	ObjectEnterCowerState(self,other)
end


function ChantForUnit(self) -- Used by units to broadcast the chant event to their own side.
	ObjectBroadcastEventToAllies(self, "BeginChanting", 9999)
end

function StopChantForUnit(self) -- Used by units to stop the chant event to their own side.
	ObjectBroadcastEventToAllies(self, "StopChanting", 9999)
end

function SpyMoving(self, other)
	print(ObjectDescription(self).." spying movement of "..ObjectDescription(other));
end

function OnGarrisonableCreated(self)
	ObjectHideSubObjectPermanently( self, "GARRISON01", true )
	ObjectHideSubObjectPermanently( self, "GARRISON02", true )
end

function OnRubbleDropshipCreated(self)
	ObjectHideSubObjectPermanently( self, "Loadref", true )
end

function OnAlienMotherShipCreated(self)
	ObjectSetObjectStatus( self, "AIRBORNE_TARGET" )
end

function OnNODInfantryICreated(self)
	ObjectHideSubObjectPermanently( self, "WEAPON_PARTICLEBM", true )
end

function OnNodVehicleMCreated(self)
	ObjectHideSubObjectPermanently( self, "NUM_VehicleM_UPG", true )
end

function OnNodVehicleOCreated(self)
	ObjectHideSubObjectPermanently( self, "B_FTR", true )
	ObjectHideSubObjectPermanently( self, "FTR", true )
	ObjectHideSubObjectPermanently( self, "FX_FTpilotflameR", true )
	ObjectHideSubObjectPermanently( self, "B_FTL", true )
	ObjectHideSubObjectPermanently( self, "FTL", true )	
	ObjectHideSubObjectPermanently( self, "FX_FTpilotflameL", true )	
	ObjectHideSubObjectPermanently( self, "HvyMGL", true )
	ObjectHideSubObjectPermanently( self, "HvyMGBarrelL", true )
	ObjectHideSubObjectPermanently( self, "MuzzleFlash_01", true )	
	ObjectHideSubObjectPermanently( self, "HvyMGR", true )
	ObjectHideSubObjectPermanently( self, "HvyMGBarrelR", true )
	ObjectHideSubObjectPermanently( self, "MuzzleFlash_02", true )	
	ObjectHideSubObjectPermanently( self, "RocketPodL", true )
	ObjectHideSubObjectPermanently( self, "RocketPodR", true )	
	ObjectHideSubObjectPermanently( self, "ModuleR", true )
	ObjectHideSubObjectPermanently( self, "ModuleBeacontR", true )
	ObjectHideSubObjectPermanently( self, "ModuleLightR", true )	
	ObjectHideSubObjectPermanently( self, "ModuleL", true )	
	ObjectHideSubObjectPermanently( self, "ModuleBeaconL", true )
	ObjectHideSubObjectPermanently( self, "ModuleLightL", true )	
	OnBaseHuskCreatorCreated(self)
end

function OnNODVehicleRCreated(self)
	ObjectHideSubObjectPermanently( self, "NUBEAM", true )
	ObjectHideSubObjectPermanently( self, "S_DETECTOR", true )
	ObjectHideSubObjectPermanently( self, "S_GENERATOR", true )
end

function TechStructureEOnCreated(self)
	ObjectHideSubObjectPermanently( self, "FXTopLightRED", true )
	ObjectHideSubObjectPermanently( self, "FXTopLightRED_Bulb", true )
	--- ObjectHideSubObjectPermanently( self, "FXTopLightGREEN", true )
	--- ObjectHideSubObjectPermanently( self, "FXTopLightGREEN_Bulb", true )
end

function NODStructureAOnCreated(self)
	ObjectHideSubObjectPermanently( self, "NSL_StructureA_UPG", true )
end



function NODStructureBOnCreated(self)
	ObjectHideSubObjectPermanently( self, "NSL_StructureB_UPG", true )
end

function NODStructureJOnCreated(self)
	ObjectHideSubObjectPermanently( self, "Rocket_UPG_1", true )
	ObjectHideSubObjectPermanently( self, "Rocket_UPG_2", true )
	ObjectHideSubObjectPermanently( self, "Rocket_UPG_3", true )
	ObjectHideSubObjectPermanently( self, "StructureJ_UPG1", true )
	ObjectHideSubObjectPermanently( self, "StructureJ_UPG2", true )
end

function GDIStructureEOnCreated(self)
	ObjectHideSubObjectPermanently( self, "GSL_StructureE_UPG", true )
end

function GDIStructureIOnCreated(self)
	ObjectHideSubObjectPermanently( self, "GSL_StructureI_UPG", true )
end

function SharedBaseHoleOnCreated(self)
	--- set USER_20 model state so I can detect the hole in WB
	ObjectSetModelCondition(self, "USER_20")
end

function OnGDIVehicleVCreated(self)
	ObjectHideSubObjectPermanently( self, "GUVehicle_UPG", true )
	ObjectHideSubObjectPermanently( self, "Weapon_UPG", true )
end

function OnGDIVehicleSCreated(self)
	ObjectSetObjectStatus( self, "REPAIR_ALLIES_WHEN_IDLE" )
end

function OnGDIVehicleMCreated(self)
	ObjectHideSubObjectPermanently( self, "GUL_VehicleM_UPG", true )
	ObjectHideSubObjectPermanently( self, "UPG_SHIELD_FX", true )
end

function CrawlerCreated(self)
	ObjectHideSubObjectPermanently( self, "TECH2", true )
	ObjectHideSubObjectPermanently( self, "TECH3", true )
end

function GideonCrawlerCreated(self)
end

function OnNodVehicleCCreated(self)
	ObjectSetObjectStatus( self, "SHIELDBODY_ENABLED" )
	ObjectHideSubObjectPermanently( self, "NODVehicleC_UPG", true )
end

-- remove upgrade from object or else it will pop back to life right away the next
-- time it dies
function OnBaseHuskCreatorCreated(self)
	ObjectRemoveUpgrade( self, "Upgrade_HuskReviveTrigger" )
end

function OnGDIVehicleACreated(self)
	ObjectHideSubObjectPermanently( self, "GUVehicleA_Gun_UPG", true )
	ObjectHideSubObjectPermanently( self, "GUVehicleA_Ammo_UPG", true )
end

function OnGDIVehicleABCreated(self)
	ObjectHideSubObjectPermanently( self, "GUS_VehicleAB_UPG", true )
end

function OnGDIVehicleACCreated(self)
	ObjectHideSubObjectPermanently( self, "GUS_VehicleAC_UPG", true )
end

function OnNODVehicleABCreated(self)
	ObjectHideSubObjectPermanently( self, "NUM_VehicleAB_UPG", true )
	ObjectHideSubObjectPermanently( self, "Treads_UPG", true )
	ObjectHideSubObjectPermanently( self, "NUM_VehicleAB_UPG01", true )
	ObjectHideSubObjectPermanently( self, "Missile_Holder_UPG", true )	
end

function OnGDIVehicleAECreated(self)
	ObjectHideSubObjectPermanently( self, "GUVehicleAE_UPG", true )
end

function OnNODVehicleBCreated(self)
	ObjectHideSubObjectPermanently( self, "NUS_VehicleB_UPG", true )
end

function OnNODStructureFCreated(self)
	ObjectHideSubObjectPermanently( self, "NSL_StructureF_UPG", true )
end

function OnGDIVehiclePCreated(self)
	ObjectHideSubObjectPermanently( self, "GUM_VehicleP_UPG", true )
end

function OnConquerVehicleCreated(self)
	ObjectSetObjectStatus( self, "AI_SKIP_UPGRADE_CRATE_SEARCH" )
end

function OnGDIVehicleADCreated(self)
	ObjectHideSubObjectPermanently( self, "GUS_VehicleAD_UPG", true )
end

function OnGDIVehicleABCreated(self)
	ObjectHideSubObjectPermanently( self, "GUM_VehicleAB_UPG", true )
end

function OnGDIVehicleAFCreated(self)
	ObjectHideSubObjectPermanently( self, "GUL_VehicleAF_UPG", true )
	ObjectHideSubObjectPermanently( self, "Refraction_Armor", true )
end

function OnGDIVehicleLCreated(self)
	ObjectHideSubObjectPermanently( self, "Gun_Upgrade", true )
end

function OnGDIVehicleLHuskCreated(self)
	OnGDIVehicleLCreated( self )
	ObjectClearObjectStatus( self, "CANNOT_PROVIDE_BUILDABILITY" )
end

function OnNodVehicleTCreated(self)
	ObjectHideSubObjectPermanently( self, "NUVehicleT_UPG", true )
end

function OnNodVehicleFCreated(self)
	ObjectHideSubObjectPermanently( self, "Upgrade2", true )
end

function OnNODVehicleWCreated(self)
	ObjectHideSubObjectPermanently( self, "MINE_UPG", true )
	ObjectHideSubObjectPermanently( self, "UPGRADE", true )	
end

function OnNodVehicleECreated(self)
	ObjectHideSubObjectPermanently( self, "NUM_VehicleE_UPG", true )
end

function OnNODVehicleICreated(self)
	ObjectHideSubObjectPermanently( self, "", true )
end

function OnNODAircraftJCreated(self)
	ObjectHideSubObjectPermanently( self, "NUM_AircraftJ_UPG", true )
end

function OnNODInfantryTCreated(self)
	ObjectHideSubObjectPermanently( self, "NODInfantryT_UPG", true )
end

function OnNODStructureDCreated(self)
	ObjectHideSubObjectPermanently( self, "NSL_StructureD_UPG", true )
	ObjectHideSubObjectPermanently( self, "IRIS", true )
end

function OnGDIAircraftOCreated(self)
	ObjectHideSubObjectPermanently( self, "GUS_AircraftO_UPG", true )
end

function OnGDIInfantryVCreated(self)
	ObjectHideSubObjectPermanently( self, "Upgrade", true )
end

function OnGDIInfantryRCreated(self)
	ObjectHideSubObjectPermanently( self, "Upgrades", true )
end

function OnGDIInfantryTGenericEvent(self, data)
	local str = tostring( data )
	if str == "hide_backpack" then
		ObjectHideSubObjectPermanently( self, "GUINFANTRYT_BACKPACK", true )
	elseif str == "hide_platform" then		
		ObjectHideSubObjectPermanently( self, "GUINFANTRYT_BASE", true )
	elseif str == "show_backpack" then
		ObjectHideSubObjectPermanently( self, "GUINFANTRYT_BACKPACK", false )
	elseif str == "show_platform" then
		ObjectHideSubObjectPermanently( self, "GUINFANTRYT_BASE", false )
	end
end

function OnGDIInfantryTCreated(self)
	ObjectHideSubObjectPermanently( self, "GUINFANTRYT_BASE", true )
end

function OnGDIStructureCCreated(self)
	ObjectHideSubObjectPermanently( self, "GSL_StructureC_UPG", true )
end

function OnGDIStructureACreated(self)
	ObjectHideSubObjectPermanently( self, "GSX_StructureA_UPG", true )
end

function OnGDIStructureBCreated(self)
	ObjectHideSubObjectPermanently( self, "GSL_StructureB_UPG", true )
end

function OnGDIStructureDCreated(self)
	ObjectHideSubObjectPermanently( self, "GSL_StructureD_UPG", true )
end

function OnGDIStructureFCreated(self)
	ObjectHideSubObjectPermanently( self, "GSL_StructureF_UPG", true )
end

function OnIonStormCreated(self)
	ObjectSetModelCondition(self, "EMOTION_DISSIDENT")
end	

function OnGDIStructureGCreated(self)
	ObjectHideSubObjectPermanently( self, "GSM_StructureG_UPG01", true )
end

function OnGDIInfantryUCreated(self)
	ObjectHideSubObjectPermanently( self, "GUS_InfantryU_UPG", true )
end

function OnNODVehicleACCreated(self)
	ObjectHideSubObjectPermanently( self, "NUL_VehicleAC_upgrade", true )
end

function OnNODVehicleACHuskCreated(self)
	OnNODVehicleACCreated( self )
	ObjectClearObjectStatus( self, "CANNOT_PROVIDE_BUILDABILITY" )
end


function OnNODInfantryUCreated(self)
	ObjectHideSubObjectPermanently( self, "Upgrade", true )
end

function OnNODInfantrySCreated(self)
	ObjectHideSubObjectPermanently( self, "NUS_InfantryS_upgrade", true )
	ObjectHideSubObjectPermanently( self, "NUS_InfantryS_suicide", true )
end

function OnNODInfantryRCreated(self)
	ObjectHideSubObjectPermanently( self, "NU_InfantryR_upgrade", true )
end

function OnNODAircraftOCreated(self)
	ObjectHideSubObjectPermanently( self, "Upgrade", true )
end

function OnNODStructureCCreated(self)
	ObjectHideSubObjectPermanently( self, "NSL_StructureC_UPG", true )
	ObjectHideSubObjectPermanently( self, "IRIS", true )
end

function OnNODStructureGCreated(self)
	ObjectHideSubObjectPermanently( self, "NSM_StructureG_UPG", true )
end

function OnNODStructureECreated(self)
	ObjectHideSubObjectPermanently( self, "NSL_StructureE_UPG", true )
end

function OnGDIVehicleAKCreated(self)
	ObjectHideSubObjectPermanently( self, "GUL_VehicleAK_UPG", true )
end

function OnNODInfantryBCreated(self)
	ObjectHideSubObjectPermanently( self, "Upgrd", true )
end

function OnGDIInfantryOCreated(self)
	ObjectHideSubObjectPermanently( self, "Upgrades", true )
end

function OnCrystalLifterCreated(self)
	ObjectHideSubObjectPermanently( self, "Tiberium_Blue", true )
end

function OnSuperCrystalLifterCreated(self)
	ObjectHideSubObjectPermanently( self, "Tiberium", true )
end

function OnNODCommandoACreated(self)
	ObjectHideSubObjectPermanently( self, "Upgrade", true )
end

function OnGDICommandoACreated(self)
	ObjectHideSubObjectPermanently( self, "CommandoA_UPG", true )
end

function OnGDICommander_3_2_Functions(self, data)
	local str = tostring( data )

	if str == "WeaponRocket" then
		ObjectHideSubObjectPermanently( self, "Rocket", false )
		ObjectHideSubObjectPermanently( self, "Rifle", true )
	elseif str == "WeaponRifle" then
		ObjectHideSubObjectPermanently( self, "Rocket", true )
		ObjectHideSubObjectPermanently( self, "Rifle", false )
	end
end

function NODStructureJRocketOnCreated(self)
	ObjectHideSubObjectPermanently( self, "Rocket_UPG_1", true )
	ObjectHideSubObjectPermanently( self, "Rocket_UPG_2", true )
	ObjectHideSubObjectPermanently( self, "Rocket_UPG_3", true )
end
