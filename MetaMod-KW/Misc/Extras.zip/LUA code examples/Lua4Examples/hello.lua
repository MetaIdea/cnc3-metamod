-- the first program in every language

write("hello world, from Lua!\n")
